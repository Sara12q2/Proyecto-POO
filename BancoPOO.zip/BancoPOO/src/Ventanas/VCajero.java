package Ventanas;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JFrame;


public class VCajero extends javax.swing.JFrame {

    public String nombreUsuario;
    public VCajero() {
        initComponents();
        
        this.setLocationRelativeTo(null); //PAntala en el centro
    }
     public void setNombre(String nombre){
         nombreUsuario=nombre;
         System.out.println("nombreee" + nombreUsuario);
         lblNombreUser.setText(nombreUsuario);
     }
     public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/banco.JPG"));
        return retValue;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton6 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Cancelar = new javax.swing.JButton();
        Cancelar1 = new javax.swing.JButton();
        DepositarSaldo = new javax.swing.JLabel();
        ConsultarSaldo = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        RetirarSaldo = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        OtrosServicios = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        DepositarSaldo1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabelMin = new javax.swing.JLabel();
        jLabelClose1 = new javax.swing.JLabel();
        lblNombreUser = new javax.swing.JLabel();

        jButton6.setText("jButton2");

        jLabel7.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        jLabel7.setText("Consultar Saldo");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 153, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 0, 51));
        jLabel1.setText("OPRIMA LA OPERACIÓN A REALIZAR");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(110, 11, 236, 28);

        Cancelar.setBackground(new java.awt.Color(204, 0, 255));
        Cancelar.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 11)); // NOI18N
        Cancelar.setText("CANCELAR");
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar);
        Cancelar.setBounds(75, 380, 100, 21);

        Cancelar1.setBackground(new java.awt.Color(204, 0, 255));
        Cancelar1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 11)); // NOI18N
        Cancelar1.setText("REGRESAR");
        Cancelar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cancelar1ActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar1);
        Cancelar1.setBounds(270, 380, 100, 21);

        DepositarSaldo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DepositarSaldoMouseClicked(evt);
            }
        });
        jPanel1.add(DepositarSaldo);
        DepositarSaldo.setBounds(74, 229, 0, 90);

        ConsultarSaldo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/consu.JPG"))); // NOI18N
        ConsultarSaldo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ConsultarSaldoMouseClicked(evt);
            }
        });
        jPanel1.add(ConsultarSaldo);
        ConsultarSaldo.setBounds(70, 60, 126, 124);

        jLabel5.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        jLabel5.setText("Consultar Saldo");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(70, 170, 101, 20);

        jLabel6.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        jLabel6.setText("Depositar Saldo");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(70, 330, 112, 20);
        jPanel1.add(jLabel8);
        jLabel8.setBounds(379, 163, 0, 0);

        RetirarSaldo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ret.JPG"))); // NOI18N
        RetirarSaldo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RetirarSaldoMouseClicked(evt);
            }
        });
        jPanel1.add(RetirarSaldo);
        RetirarSaldo.setBounds(273, 82, 100, 81);

        jLabel10.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        jLabel10.setText("Retirar Saldo");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(273, 169, 112, 20);

        OtrosServicios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/mov.JPG"))); // NOI18N
        OtrosServicios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OtrosServiciosMouseClicked(evt);
            }
        });
        jPanel1.add(OtrosServicios);
        OtrosServicios.setBounds(270, 230, 90, 90);

        jLabel12.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 18)); // NOI18N
        jLabel12.setText("Movimientos");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(280, 330, 112, 20);

        DepositarSaldo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/pi.JPG"))); // NOI18N
        DepositarSaldo1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DepositarSaldo1MouseClicked(evt);
            }
        });
        jPanel1.add(DepositarSaldo1);
        DepositarSaldo1.setBounds(60, 230, 120, 100);

        jPanel2.setBackground(new java.awt.Color(102, 0, 102));

        jLabel2.setFont(new java.awt.Font("Bookman Old Style", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 153, 255));
        jLabel2.setText("ENBISU");

        jLabelMin.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabelMin.setForeground(new java.awt.Color(204, 102, 255));
        jLabelMin.setText("-");
        jLabelMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMinMouseClicked(evt);
            }
        });

        jLabelClose1.setBackground(new java.awt.Color(204, 102, 255));
        jLabelClose1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelClose1.setForeground(new java.awt.Color(204, 102, 255));
        jLabelClose1.setText("X");
        jLabelClose1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelClose1MouseClicked(evt);
            }
        });

        lblNombreUser.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblNombreUser, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(117, 117, 117)
                .addComponent(jLabelMin)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelClose1)
                .addGap(3, 3, 3))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelMin, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabelClose1))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblNombreUser)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabelMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMinMouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMinMouseClicked

    private void DepositarSaldo1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DepositarSaldo1MouseClicked
        DepositarSaldo o=new DepositarSaldo();
        o.setVisible(true);
        o.pack();
        o.setLocationRelativeTo(null);
        o.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
        o.setNombre(lblNombreUser.getText());
        // TODO add your handling code here:
    }//GEN-LAST:event_DepositarSaldo1MouseClicked

    private void OtrosServiciosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OtrosServiciosMouseClicked

        verMovimientos o=new verMovimientos();
        o.setVisible(true);
        o.pack();
        o.setLocationRelativeTo(null);
        o.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        o.setNombre(lblNombreUser.getText());
        this.dispose();
        
    }//GEN-LAST:event_OtrosServiciosMouseClicked

    private void RetirarSaldoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RetirarSaldoMouseClicked
        RetirarSaldo o=new RetirarSaldo();
        o.setVisible(true);
        o.pack();
        o.setLocationRelativeTo(null);
        o.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
        o.setNombre(lblNombreUser.getText());
    }//GEN-LAST:event_RetirarSaldoMouseClicked

    private void ConsultarSaldoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ConsultarSaldoMouseClicked
        ConsultarSaldo o=new ConsultarSaldo();
        o.setVisible(true);
        o.pack();
        o.setLocationRelativeTo(null);
        o.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        o.setNombre(nombreUsuario);
        this.dispose();
    }//GEN-LAST:event_ConsultarSaldoMouseClicked

    private void DepositarSaldoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DepositarSaldoMouseClicked
        DepositarSaldo o=new DepositarSaldo();
        o.setVisible(true);
        o.pack();
        o.setLocationRelativeTo(null);
        o.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_DepositarSaldoMouseClicked

    private void Cancelar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cancelar1ActionPerformed
        this.dispose();
        EntrarCajero login=new EntrarCajero();
        login.setVisible(true);
        login.setLocationRelativeTo(null);
    }//GEN-LAST:event_Cancelar1ActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_CancelarActionPerformed

    private void jLabelClose1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelClose1MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabelClose1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VCajero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VCajero().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton Cancelar;
    public static javax.swing.JButton Cancelar1;
    private javax.swing.JLabel ConsultarSaldo;
    private javax.swing.JLabel DepositarSaldo;
    private javax.swing.JLabel DepositarSaldo1;
    private javax.swing.JLabel OtrosServicios;
    private javax.swing.JLabel RetirarSaldo;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabelClose1;
    private javax.swing.JLabel jLabelMin;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblNombreUser;
    // End of variables declaration//GEN-END:variables
}
