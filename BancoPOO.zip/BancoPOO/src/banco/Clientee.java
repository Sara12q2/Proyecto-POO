
package banco;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

public class Clientee implements Serializable{
    private String nombre;
    private int numCuenta;
    private String direccion;
    private int contraseña;
    private ArrayList <Cuenta> cuentas=new ArrayList<>();
    
    
    public Clientee(){
        nombre="";
        numCuenta = 0;
        numCuenta=0;
        direccion = "";
        contraseña = 0;
    }
    public Clientee(String nombre, String direccion){
        Random variable1 = new Random();
        int v = variable1.nextInt(1000-1+1)+9999;
        Random variable2 = new Random();
        int v2 = variable2.nextInt(100000-1+1)+999999;
        numCuenta = v2;
        this.nombre=nombre;
        this.direccion = direccion;
        contraseña = v;
 
    }
    
    public Clientee(String nombre,String direccion,int numCuenta){
        this.nombre=nombre;
        this.direccion=direccion;
        this.numCuenta=numCuenta;
    }
public void serializarCliente(Cliente clienteASerializar){
    try{
        ObjectOutputStream serializando=new ObjectOutputStream(new FileOutputStream("C:\\Clientes\\Serializable\\" + clienteASerializar.getNombre()));
        serializando.writeObject(clienteASerializar);
        serializando.close();
    }catch(IOException ioe){
        ioe.printStackTrace();
    }
}
public String getNombre(){
    return nombre;
}
public void obtenerInfo(){
    System.out.println("Nombre del Cliente: " + nombre);
    System.out.println("Informacion de sus cuentas");
    Clientee cl= new Clientee("Pablo","dir");
    
    for(int i=0;i<cuentas.size();i++){
       if(cuentas.get(i) instanceof CuentaDeAhorros)
        System.out.println("Cuenta de Ahorros   saldo:"+cuentas.get(i).consultar());
       else
        System.out.println("Cuenta de Cheques   saldo:"+cuentas.get(i).consultar());
    }
    System.out.println("");
   
}

public Cuenta obtenerCuenta(int index){
    Cuenta aux;
    aux = cuentas.get(index-1);
    return aux;
}

  public void agregarCuenta(Cuenta cta){
    cuentas.add(cta);
  }  

public int obtenerNumCtas(){
    int numero;
    numero = cuentas.size();
    return numero;
}

public int ObtenerNoCuenta(Cuenta a){
    int aux=0;
    for(int i=0;i<cuentas.size();i++){
        if(cuentas.get(i)==a)
            aux = i+1;
            return aux;
    }
    if(aux==0){
        System.out.println("La cuenta especificada no se ha encontrado");
    }
    return aux;
}

 public  void Fecha(){
     Date fecha=new Date();
     
        System.out.println("Dia: "+fecha.getDay()+"\n"
                         + "Mes: "+(fecha.getMonth()+1)+"\n"
                         + "Año: "+(fecha.getYear()+1900));
                  
    }
 
 public void CrearArchivos() throws IOException{
    File directorio;
    File archivo;
     directorio=new File("C:\\Clientes\\Cliente-"+nombre);
            directorio.mkdir();
            directorio=new File("C:\\Clientes\\Cliente-"+nombre+"\\CuentaAhorros");
            directorio.mkdir();
            directorio=new File("C:\\Clientes\\Cliente-"+nombre+"\\CuentaCheques");
            directorio.mkdir();
            archivo=new File("C:\\Clientes\\Cliente-"+nombre +"\\CuentaAhorros\\", nombre+"Ahorros" +".txt");
            archivo.createNewFile();
            archivo=new File("C:\\Clientes\\Cliente-"+nombre +"\\CuentaCheques\\", nombre+"Cheques" +".txt");
            archivo.createNewFile();
            archivo=new File("C:\\Clientes\\Cliente-"+nombre+"\\","Informacion-cliente-"+nombre+".txt");
            archivo.createNewFile();
 }
 
 public void llenarArchivo(){
     try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\Cliente-"+nombre +"\\"+"Informacion-cliente-"+nombre+".txt"),true))){
          int numero;
          numero = cuentas.size(); 
         
           out.write(nombre+"\n");
           out.write(numCuenta+"\n");
           out.write(cuentas.size()+"\n");
           out.write(contraseña+"\n");
           out.write(direccion+"\n");
       }
       catch(IOException ioe){
           ioe.printStackTrace();
       }

       }
 
 public void llenarCuentas(){
     
       for(int i=0;i<cuentas.size();i++){
       if(cuentas.get(i) instanceof CuentaDeAhorros){
           try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\Cliente-"+nombre+"\\CuentaAhorros\\"+nombre+"Ahorros.txt"),true))){         
           out.write("Numero de cuenta: "+i+"\n");
           out.write("Saldo disponible : "+cuentas.get(i).consultar()+"\n");
       }
       catch(IOException ioe){
           ioe.printStackTrace();
       }
       }
       else{
           try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\Cliente-"+nombre+"\\CuentaCheques\\"+nombre+"Cheques.txt"),true))){         
           out.write("Numero de cuenta: "+i+"\n");
           out.write("Saldo disponible : "+cuentas.get(i).consultar()+"\n");
       }
       catch(IOException ioe){
           ioe.printStackTrace();
       }
       }
    }
 }

        
}
