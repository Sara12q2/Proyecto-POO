package banco;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Sucursal implements EntidadCredito,EntidadDeposito{
private ArrayList<Cliente>  clientes = new ArrayList<Cliente>();
private String nombre;

public Sucursal(String nombre){
    this.nombre = nombre;
}

public void agregarCliente(Cliente u){
    clientes.add(u);
}

public void DarClienteDeBaja(int index){
    clientes.remove(index-1);
  }

public int NumeroClientes(){
    int aux;
    aux = clientes.size();
    return aux;
}

public void ReportarClientes(){
            System.out.println("Banco:  "+nombre);
            for(int i=0; i<clientes.size();i++){
                System.out.println("Numero de cliente:  "+(i+1));
                clientes.get(i).obtenerInfo();
                System.out.println("Numero de cuentas:  "+clientes.get(i).obtenerNumCtas());
            } 
            
            System.out.println("\n");
}

    @Override
    public void EdidadCrediticia() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        JOptionPane.showMessageDialog(null, "ENTIDAD CREDITICIA");
    }

    @Override
    public void EntidadDeposito() {
        JOptionPane.showMessageDialog(null,"ENTIDAD DEPOSITOS");
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        
}