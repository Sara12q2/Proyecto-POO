package banco;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class Cliente implements Serializable{
    private String nombre;
    private String usuario;
    private String numCliente;
    private String numCuenta;
    private ArrayList <Cuenta> cuentas=new ArrayList<>();
    public Cliente(){
        nombre="";
        usuario="";
        numCliente="";
        numCuenta="";
        ArrayList <Cuenta>aux=new ArrayList<>();
    }
    public Cliente(String nombre){
        this.nombre=nombre;
        this.usuario="";
        this.numCliente="";
        this.numCuenta="";
    }
    public Cliente(String nombre,String usuario,String numCliente,String numCuenta){
        this.nombre=nombre;
        this.numCliente=numCliente;
        this.usuario=usuario;
        this.numCuenta=numCuenta;
    }
public void serializarCliente(Cliente clienteASerializar){
    try{
        ObjectOutputStream serializando=new ObjectOutputStream(new FileOutputStream("C:\\Clientes\\Serializable\\" + clienteASerializar.getNombre()));
        serializando.writeObject(clienteASerializar);
        serializando.close();
    }catch(IOException ioe){
        ioe.printStackTrace();
    }
}
public String getNombre(){
    return nombre;
}
public void obtenerInfo(){
    System.out.println("Nombre del Cliente: " + nombre);
    System.out.println("Informacion de sus cuentas");
    Cliente cl= new Cliente("Pablo");
    
    for(int i=0;i<cuentas.size();i++){
       if(cuentas.get(i) instanceof CuentaDeAhorros)
        System.out.println("Cuenta de Ahorros   saldo:"+cuentas.get(i).consultar());
       else
        System.out.println("Cuenta de Cheques   saldo:"+cuentas.get(i).consultar());
    }
    System.out.println("");
   
}

public Cuenta obtenerCuenta(int index){
    Cuenta aux;
    aux = cuentas.get(index-1);
    return aux;
}

  public void agregarCuenta(Cuenta cta){
    cuentas.add(cta);
  }  

public int obtenerNumCtas(){
    int numero;
    numero = cuentas.size();
    return numero;
}

public int ObtenerNoCuenta(Cuenta a){
    int aux=0;
    for(int i=0;i<cuentas.size();i++){
        if(cuentas.get(i)==a)
            aux = i+1;
            return aux;
    }
    if(aux==0){
        System.out.println("La cuenta especificada no se ha encontrado");
    }
    return aux;
}

 public  void Fecha(){
     Date fecha=new Date();
     
        System.out.println("Dia: "+fecha.getDay()+"\n"
                         + "Mes: "+(fecha.getMonth()+1)+"\n"
                         + "Año: "+(fecha.getYear()+1900));
                  
    }
        
}
