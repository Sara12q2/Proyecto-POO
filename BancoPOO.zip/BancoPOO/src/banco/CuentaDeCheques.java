package banco;




public class CuentaDeCheques extends Cuenta{
    private double montoSobregiro;
    public CuentaDeCheques(double saldoIni,double sobregiro){
        super(saldoIni);
        montoSobregiro = sobregiro;
    }
    
    public CuentaDeCheques(double saldoIni){
        super(saldoIni);
    }
    
    public void retirar(double monto){
        if(monto<=saldo){
            saldo  = saldo - monto;
        }
        else{
            if(monto<=(saldo+montoSobregiro)){
                double aux;
                aux = monto - saldo;
                saldo = 0;
                montoSobregiro = montoSobregiro - aux;
            }
            else{
                saldo = saldo + montoSobregiro;
                System.out.println("Lo sentimos, su transaccion fue cancelada");
                System.out.println("El monto requerido: "+"["+monto+"] " + "supera su saldo mas su sobregiro establecido: "+ "["+saldo+"]");
            }
        }
    }
    
    public void consultarSobregiro(){
        System.out.println("Su sobregiro es:  "+ montoSobregiro);
    }
}