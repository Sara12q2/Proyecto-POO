
package banco;


public interface EntidadCredito {
    public void EdidadCrediticia();
}
