package banco;




public class CuentaDeAhorros extends Cuenta{
    private double tasaDeInteres;
    
    
    public  CuentaDeAhorros(double SaldoIni, double tasaInteres){
    super(SaldoIni);
    tasaDeInteres=tasaInteres;
    saldo  = saldo + saldo*tasaInteres;

}
    public double Consultar(){
    double aux;
    aux = super.consultar()+super.consultar()*tasaDeInteres;
    return aux;
    }  
}

    
