
package banco;


public interface EntidadDeposito {
    public void EntidadDeposito();
}
