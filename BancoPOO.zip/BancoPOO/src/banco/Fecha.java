
package banco;

import java.util.Date;


public class Fecha {
  
     public  void Fecha(){
         
     Date fecha=new Date();
     
     System.out.println("Fecha Actual "+fecha.getDay()+"/"+fecha.getMonth()+"/"+fecha.getYear());
                       
     
       // System.out.println("Dia: "+fecha.getDay()+"\"+ Mes: "+(fecha.getMonth()+1)+"\n"
         //                + "Año: "+(fecha.getYear()+1900));
                  
    }
}
