package banco;

import java.util.Date;

public class UsoTodo{
   

public static void main(String[] args){
   Fecha fec=new Fecha();
   fec.Fecha();
   Clientee p=new Clientee();
   p.obtenerInfo();
//Creamos cuentas de ahorro
CuentaDeAhorros cda1 = new CuentaDeAhorros(1000, 0.1);
CuentaDeAhorros cda2 = new CuentaDeAhorros(2000, 0.2);
CuentaDeAhorros cda3 = new CuentaDeAhorros(3000, 0.3);
//Creamos cuentas de cheques
CuentaDeCheques cdc1 = new CuentaDeCheques(1000, 100);
CuentaDeCheques cdc2 = new CuentaDeCheques(2000, 200);
CuentaDeCheques cdc3 = new CuentaDeCheques(3000, 300);
//Creamos 3 clientes
Cliente cli1 = new Cliente("Quijote");
Cliente cli2 = new Cliente("Sancho");
Cliente cli3 = new Cliente("Rocinante");
//Agregamos cuentas al cliente Quijote
cli1.agregarCuenta(cda1);
cli1.agregarCuenta(cdc1);

//Agregamos cuentas al cliente Sancho
cli2.agregarCuenta(cda2);
cli2.agregarCuenta(cdc2);
//Agregamos cuentas al cliente Rocinante
cli3.agregarCuenta(cda3);
cli3.agregarCuenta(cdc3);
//Obtenemos la informacion de cada cliente
cli1.obtenerInfo();
cli2.obtenerInfo();
cli3.obtenerInfo();
  


}
}