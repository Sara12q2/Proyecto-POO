
package banco;

import Ventanas.MenuInicio;


public class Banco {


    public static void main(String[] args) {
      MenuInicio menuInicio=new MenuInicio();
      menuInicio.setVisible(true);
      menuInicio.setLocationRelativeTo(null);
    }
    
}
