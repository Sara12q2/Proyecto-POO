package banco;

import java.util.Date;




public class Cuenta {
    protected double saldo;
   
    public Cuenta(double saldoInicial){
    saldo=saldoInicial; 
    }
    
    public  double consultar(){
    return saldo;
    }
    
    public void Depositar(double Monto){
    saldo=saldo+Monto;
    }
    
    public void Retirar(double Monto){
    if(Monto<=saldo)
            saldo=saldo-Monto;
    else
            System.out.println("No cuenta con el saldo suficiente para realizar el retiro, su saldo es: "+saldo);
    }
    
     public  void Fecha(){
     Date fecha=new Date();
     
        System.out.println("Dia: "+fecha.getDay()+"\n"
                         + "Mes: "+(fecha.getMonth()+1)+"\n"
                         + "Año: "+(fecha.getYear()+1900));
                  
    }
    
}

/*public Cuenta obtenerCuenta(int index){
     
}*/