package banco;



public class HerenciaCuentas{
 /**public static void main(String[ ] args){
 //Creamos una instancia de CuentaDeAhorros
 CuentaDeAhorros ca1 = new CuentaDeAhorros(1000, 0.3);
 //Creamos una instancia de CuentaDeCheques
 CuentaDeCheques cch1 = new CuentaDeCheques(1000, 1000);
 //Consultamos la cuenta de ahorros
 System.out.println("cuenta de ahorros: " + ca1.consultar());
 //Consultamos la cuenta de cheques
 System.out.println("cuenta de cheques, saldo: " + cch1.consultar());
 cch1.retirar(1000);
 System.out.println("cuenta de cheques, saldo: " + cch1.consultar());
 cch1.retirar(500);
 System.out.println("cuenta de cheques, saldo: " + cch1.consultar());
 cch1.consultarSobregiro();
 cch1.retirar(499);
 cch1.consultarSobregiro();
 cch1.retirar(2);
 }**/
}

/*public Cuenta obtenerCuenta(int index){
     
}*/