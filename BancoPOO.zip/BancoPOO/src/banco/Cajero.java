
package banco;


public class Cajero {
   private double saldo;
   
   
   public void ConsultarSaldo(double saldoContenido){
   this.saldo=saldoContenido;
   }
   
   public void RetirarSaldo(double saldoRet){
   this.saldo=saldoRet;
   }
   
   public void DepositarSaldo(double saldoAct){
   this.saldo=saldoAct;
   }
   
   public void Historial(String nombre){
   
   
   }
   
  
   
   }



    
 
    