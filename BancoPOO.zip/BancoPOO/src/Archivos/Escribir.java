package Archivos;




import VentanaBanco.Registrar;
import banco.Cliente;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
 import javax.swing.UIManager;
public class Escribir
{
   Date fecha=new Date();
    File archivo;
    File directorio;
    FileReader leer;
    BufferedReader almacen;
    PrintWriter escribir;
    public Escribir(){
         crearEscribirArchivos();
    }
    
 

    
    
    
    public void crearEscribirArchivos(){
        
        try{
            directorio=new File("C:\\Clientes");//Creamos carpeta para almacenar todos los clientes
            directorio.mkdir();//ejecutamos el comando para crear la carpeta 
            directorio=new File("C:\\Clientes\\Serializable");
            directorio.mkdir();
             archivo=new File("C:\\Clientes\\","cuenta.txt");
       archivo.createNewFile();
       archivo=new File("C:\\Clientes\\","pass.txt");
       archivo.createNewFile();
        archivo=new File("C:\\Clientes\\","usuario.txt");
       archivo.createNewFile();
       
       
         }catch(IOException ioe){
             ioe.printStackTrace();
         }
       
    }
    public void crearCarpetaCientes(String nombreArchivo){
        
        try{
            
            
            directorio=new File("C:\\Clientes\\Cliente-"+nombreArchivo);
            directorio.mkdir();
            directorio=new File("C:\\Clientes\\Cliente-"+nombreArchivo+"\\CuentaAhorros");
            directorio.mkdir();
            directorio=new File("C:\\Clientes\\Cliente-"+nombreArchivo+"\\CuentaCheques");
            directorio.mkdir();
            archivo=new File("C:\\Clientes\\Cliente-"+nombreArchivo +"\\CuentaAhorros\\", 
                    nombreArchivo+"Ahorros" +".txt");
            archivo.createNewFile();
             try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\Cliente-"+
                     nombreArchivo+"\\CuentaAhorros"+
                  "\\"+nombreArchivo+"Ahorros.txt"),true))){
            
             out.write("0");
             
    }  catch (FileNotFoundException ex) {
           Logger.getLogger(Escribir.class.getName()).log(Level.SEVERE, null, ex);
       }
            archivo=new File("C:\\Clientes\\Cliente-"+nombreArchivo +"\\CuentaCheques\\", nombreArchivo+"Cheques" +".txt");
            archivo.createNewFile();
            archivo=new File("C:\\Clientes\\Cliente-"+nombreArchivo +"\\","Informacion-cliente-"+nombreArchivo+".txt");
            archivo.createNewFile();
            archivo=new File("C:\\Clientes\\Cliente-"+nombreArchivo +"\\","movimientos.txt");
            archivo.createNewFile();
      
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
    public boolean  EliminarArchivo(String nombreArchivo){
     
       archivo=new File("C:\\Clientes\\Cliente-"+ nombreArchivo +"\\Informacion-cliente-"+nombreArchivo + ".txt");
    return archivo.delete();
   
    
    }
    
    
    
    
    
   public boolean comprobarExistenciaArchivo(String nombreArchivo){
       archivo=new File("C:\\Clientes\\Cliente-"+ nombreArchivo +"\\Informacion-cliente-"+nombreArchivo + ".txt");
       return archivo.exists();
   }
  
   public void llenarArchivoCliente(String cadenaCompleta,String nombreArchivo){
       try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\Cliente-"+nombreArchivo +"\\"+"Informacion-cliente-"+nombreArchivo+".txt"),true))){
           out.write(cadenaCompleta);
       }
       catch(IOException ioe){
           ioe.printStackTrace();
       }
   }
   public void llenaLogin(String texto, String contrasenia,String usuario){
   
       try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\cuenta.txt"),true))){
          
           out.write("\n"+texto);
           
       }
       catch(IOException ioe){
           ioe.printStackTrace();
       }
        try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\usuario.txt"),true))){
          
           out.write("\n"+usuario);
           
       }
       catch(IOException ioe){
           ioe.printStackTrace();
       }
       try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\pass.txt"),true))){
          
           out.write("\n"+contrasenia);
       }
       catch(IOException ioe){
           ioe.printStackTrace();
       }
   }
   public boolean compruebaExistenciaNumeroDeCuenta(String numTarjeta){
            String cuenta=""; 
            try{
                 leer=new FileReader("C:\\Clientes\\cuenta.txt");
                 almacen=new BufferedReader(leer);
                 while(cuenta != null){
                     try{
                       cuenta=almacen.readLine();
                       if(cuenta != null){
                          
                           if(numTarjeta.equalsIgnoreCase(cuenta)){
                              
                               return false;
                           }
                       }
                     }catch(IOException ioe){
                         ioe.printStackTrace();
                     }
                 }
                 
             }catch(FileNotFoundException fnfe){
                 fnfe.printStackTrace();
             }
            return true;
   }
    public void datos(String nombre, String apellido,String usuario,String contrasenia, String ReContrasenia,String NTarjeta, String NCelular, String NCliente){
      Cliente cliente;
       if(contrasenia.equals(ReContrasenia)){
          
           if(comprobarExistenciaArchivo(usuario)){
           JOptionPane.showMessageDialog(null,"El cliente ya existe");
       }else{
           
          if(compruebaExistenciaNumeroDeCuenta(NTarjeta)){
           crearCarpetaCientes(usuario);
           llenarArchivoCliente(nombre +","+apellido+","+usuario+","+ contrasenia + ","+ReContrasenia+","+NTarjeta+","+NCelular+","+NCliente,usuario);
           llenaLogin(NTarjeta,contrasenia,usuario);  
           JOptionPane.showMessageDialog(null,"USUARIO INGRESADO CORRECTAMENTE");
           cliente=new Cliente(nombre +" "+ apellido,usuario,NCliente,NTarjeta);
           cliente= new Cliente(nombre+" "+ apellido, usuario, NCliente, NTarjeta);
           
           cliente.serializarCliente(cliente);// se serializa el objeto Cliente
           
          }else{
            JOptionPane.showMessageDialog(null,"EL NUMERO DE CUENTA YA EXISTE");
        }
       }
       }else{
           JOptionPane.showMessageDialog(null,"CONTRASEÑAS DIFERENTES, INGRESA LA MISMA CONTRASEÑA");
       }
       
    } 
    public String regresarContra(String nombreUsuario) {
         String linea,contrasenia = "\n";
        try(BufferedReader br = new BufferedReader(new FileReader("C:\\Clientes\\Cliente-"+ nombreUsuario+"\\Informacion-cliente"+nombreUsuario +".txt"))){
            while ((linea = br.readLine()) != null) {
                String[] columnas = linea.split(",");
                contrasenia=contrasenia+ columnas[2];
               // contrasenia=contrasenia+"Telefono:"+ columnas[1]+ "\n RFC:" + columnas[2];
            }
            }catch (FileNotFoundException ex) {
                System.out.println("Error. No se tiene registro de ese archivo");
            }
            catch (IOException ioe) {
                ioe.printStackTrace();
            }
        return contrasenia;
    }
    //entrada al cajero
    public boolean compruebaPinYUsuario(String usuario, String pin){
            String cuenta="";
            boolean estado=false;
        try{
                 leer=new FileReader("C:\\Clientes\\usuario.txt");
                 almacen=new BufferedReader(leer);
                 while(cuenta != null){
                     try{
                       cuenta=almacen.readLine();
                       if(cuenta != null){
                          
                           if(usuario.equalsIgnoreCase(cuenta)){
                              
                              // JOptionPane.showMessageDialog(null,"Correcto");
                               estado=true;
                           }
                       }
                     }catch(IOException ioe){
                         ioe.printStackTrace();
                     }
                 }
                 
                 if(estado){
                     cuenta="";
                     try{
                         leer=new FileReader("C:\\Clientes\\pass.txt");
                         almacen=new BufferedReader(leer);
                         while(cuenta != null){
                             try{
                                 cuenta=almacen.readLine();
                                 if(cuenta!=null){
                                     if(pin.equalsIgnoreCase(cuenta)){
                                         return (estado && true);
                                     }
                                 }
                             }catch(IOException ioe){
                                 ioe.printStackTrace();
                             }
                         }
                     }catch(IOException ioe){
                         ioe.printStackTrace();
                     }
                 }
                 
                 
                 
             }catch(FileNotFoundException fnfe){
                 fnfe.printStackTrace();
             }
        return false;
    }
    
 
    
     public boolean compruebaNombreContraseña(String nom, String pin){
            String nombre="";
            boolean estado=false;
        try{
                 leer=new FileReader("C:\\Clientes\\usuario.txt");
                 almacen=new BufferedReader(leer);
                 while(nombre!= null){
                     try{
                       nombre=almacen.readLine();
                       if(nombre!= null){
                          
                           if(nom.equalsIgnoreCase(nombre)){
                              
                              // JOptionPane.showMessageDialog(null,"Correcto");
                               estado=true;
                           }
                       }
                     }catch(IOException ioe){
                         ioe.printStackTrace();
                     }
                 }
                 
                 if(estado){
                     nombre="";
                     try{
                         leer=new FileReader("C:\\Clientes\\pass.txt");
                         almacen=new BufferedReader(leer);
                         while(nombre != null){
                             try{
                                 nombre=almacen.readLine();
                                 if(nombre!=null){
                                     if(pin.equalsIgnoreCase(nombre)){
                                         return (estado && true);
                                     }
                                 }
                             }catch(IOException ioe){
                                 ioe.printStackTrace();
                             }
                         }
                     }catch(IOException ioe){
                         ioe.printStackTrace();
                     }
                 }
                 
                 
                 
             }catch(FileNotFoundException fnfe){
                 fnfe.printStackTrace();
             }
        return false;
    }
    
   public void depositarCuenta(String nombre,String cantidad){
    String cadDeposito=nombre +" depositó $ "+ Double.parseDouble(cantidad)+ "en la fecha: "+
            fecha.getDay()+ "/"+(fecha.getMonth()+1) +"/" +(fecha.getYear()+1900);
          try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\Cliente-"+nombre+
                  "\\movimientos.txt"),true))){
            
             out.write("\n" + cadDeposito);
    actualizarSaldo(nombre, Double.parseDouble(cantidad));
    }  catch (FileNotFoundException ex) {
           Logger.getLogger(Escribir.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   public void retirarCuenta(String nombre,String cantidad){
    String cadDeposito=nombre +" retiro $ "+ Double.parseDouble(cantidad)+ "en la fecha: "+
            fecha.getDay()+"/"+ (fecha.getMonth()+1) +" /" + (fecha.getYear()+1900);
          try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\Cliente-"+nombre+
                  "\\movimientos.txt"),true))){
            
             out.write("\n" + cadDeposito);
             actualizarSaldo(nombre, (Double.parseDouble(cantidad)*-1));
    }  catch (FileNotFoundException ex) {
           Logger.getLogger(Escribir.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   public String movimientos(String nombre){
       System.out.println("nombreeeeeeee" + nombre);
      String linea="",cad="";
       try{
                 leer=new FileReader("C:\\Clientes\\Cliente-"+ nombre + "\\"+"movimientos.txt");
                 almacen=new BufferedReader(leer);
                 while(linea != null){
                     try{
                       linea=almacen.readLine();
                       if(linea != null){
                          cad+=linea + "\n";
                       }
                     }catch(IOException ioe){
                         ioe.printStackTrace();
                     }
                 }
                 
                 
                 
             }catch(FileNotFoundException fnfe){
                 fnfe.printStackTrace();
             }
       return cad;
   }
   public void actualizarSaldo(String nombre,double cantidadActualizar){
       String cantidad="", cantidadLeida="";
       double numero=0;
        String saldoActual=obtenerSaldo(nombre);
        System.out.println("SALDO ACTUAL " + saldoActual);
       numero=(Double.parseDouble(saldoActual)+ cantidadActualizar);
       System.out.println("SALDO FINAL: " + numero);
       try{
           escribir=new PrintWriter("C:\\Clientes\\Cliente-"+nombre+"\\CuentaAhorros"+"\\"+nombre+"Ahorros.txt");
           escribir.println(numero + " ");
           escribir.close();
       }catch(IOException ioe){
           ioe.printStackTrace();
       }
//      try(PrintWriter out=new PrintWriter(new FileOutputStream(("C:\\Clientes\\Cliente-"+nombre+"\\CuentaAhorros"+
//                  "\\"+nombre+"Ahorros.txt"),true))){
//            
//             out.write(numero+"");
//      }catch(IOException ioe){
//          ioe.printStackTrace();
//      }
   }
   public String obtenerSaldo(String nombre){
       String cantidad="", cantidadLeida="";
       double numero=0;
       try{
           leer=new FileReader("C:\\Clientes\\Cliente-"+nombre + "\\CuentaAhorros\\"+
                   nombre+"Ahorros.txt");
           almacen=new BufferedReader(leer);
       while(cantidad !=null){
           try{
               cantidad=almacen.readLine();
               if(cantidad !=null){
                   
                   cantidadLeida+=cantidad+"\n";
                  System.out.println("cantidaaaaaad" + cantidadLeida);
               };
           }catch(IOException ioe){
               ioe.printStackTrace();
           }
       }
       }catch(IOException ioe){
           ioe.printStackTrace();
       }
        return cantidadLeida;
   }
}
   
 